<div class="footer__nav">
    <ul>
        <li><a href="<?php echo esc_url('https://wpdeveloper.net/about/'); ?>" target="_blank" rel="nofollow"><?php _e('About Us', 'disable-comments'); ?></a></li>
        <li><a href="<?php echo esc_url('https://wpdeveloper.net/plugins/'); ?>" target="_blank" rel="nofollow"><?php _e('All Plugins', 'disable-comments'); ?></a></li>
        <li><a href="<?php echo esc_url('https://wpdeveloper.net/support/'); ?>" target="_blank" rel="nofollow"><?php _e('Support Forum', 'disable-comments'); ?></a></li>
        <li><a href="<?php echo esc_url('https://wpdeveloper.net/docs/'); ?>" target="_blank" rel="nofollow"><?php _e('Docs', 'disable-comments'); ?></a></li>
        <li><a href="<?php echo esc_url('https://wpdeveloper.net/terms-and-conditions/'); ?>" target="_blank" rel="nofollow"><?php _e('Terms Of Service', 'disable-comments'); ?></a></li>
        <li><a href="<?php echo esc_url('https://wpdeveloper.net/privacy-policy/'); ?>" target="_blank" rel="nofollow"><?php _e('Privacy', 'disable-comments'); ?></a></li>
    </ul>
</div>